/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.general.util;


/**
 *
 * @author knauth
 */
public class NotYetImplementedException extends RuntimeException
{

	public NotYetImplementedException()
	{
	}

	public NotYetImplementedException(String msg)
	{
		super(msg);
	}

}
