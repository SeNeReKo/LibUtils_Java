/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.general.util;


/**
 *
 * @author knauth
 */
public class NotImplementedException extends RuntimeException
{

	public NotImplementedException()
	{
	}

	public NotImplementedException(String msg)
	{
		super(msg);
	}

}
